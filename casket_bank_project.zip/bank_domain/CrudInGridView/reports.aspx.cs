﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
namespace CrudInGridView
{
    public partial class reports : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                LoadData();

            }
        }
        protected void btnLogout_Click(object sender, EventArgs e)
        {
            Session.Abandon();
            Response.Redirect("Login.aspx");

        }
        void LoadData()
        {
            DataTable dt = new DataTable();
            DataTable dt2 = new DataTable();
            DataTable dt3 = new DataTable();

            DataTable dt4 = new DataTable();

            using (SqlConnection con = new SqlConnection(@"Data Source=HARI2908\SQLEXPRESS;Initial Catalog=bankdomain;Integrated Security=True;Pooling=False"))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("SELECT Acc_type,COUNT(Number_of_accounts) AS No_of_Accounts FROM Branch_Account GROUP BY Acc_type", con);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(dt);
                SqlCommand cmd2 = new SqlCommand("SELECT Branch_name, Account_total FROM Ac_Branch", con);
                SqlDataAdapter da2 = new SqlDataAdapter(cmd2);
                da2.Fill(dt2);

                SqlCommand cmd3 = new SqlCommand("SELECT Lt.Ltype_Name,count(L.Loan_type) as count FROM Loan L JOIN Loan_type Lt ON Lt.Ltype_ID = L.Loan_type GROUP BY Lt.Ltype_Name", con);
                SqlDataAdapter da3 = new SqlDataAdapter(cmd3);
                da3.Fill(dt3);


                SqlCommand cmd4 = new SqlCommand("SELECT Status,COUNT(Loan_status.count) As Number_of_loanacc FROM Loan_status group by Status", con);
                SqlDataAdapter da4 = new SqlDataAdapter(cmd4);
                da4.Fill(dt4);

                con.Close();
            }
            string[] x2 = new string[dt2.Rows.Count];
            int[] y2 = new int[dt2.Rows.Count];
        
            for (int i = 0; i < dt2.Rows.Count; i++)
            {
                x2[i] = dt2.Rows[i][0].ToString();
                y2[i] = Convert.ToInt32(dt2.Rows[i][1]);
            }
            Chart2.Series[0].Points.DataBindXY(x2, y2);

            Chart2.Series[0].ChartType = System.Web.UI.DataVisualization.Charting.SeriesChartType.Line;

            string[] x = new string[dt.Rows.Count];
            int[] y = new int[dt.Rows.Count];
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                x[i] = dt.Rows[i][0].ToString();
                y[i] = Convert.ToInt32(dt.Rows[i][1]);
            }


            Chart1.Series[0].Points.DataBindXY(x, y);

            Chart1.Series[0].ChartType = System.Web.UI.DataVisualization.Charting.SeriesChartType.Bar;

            string[] x3 = new string[dt3.Rows.Count];
            int[] y3 = new int[dt3.Rows.Count];
            for (int i = 0; i < dt3.Rows.Count; i++)
            {
                x3[i] = dt3.Rows[i][0].ToString();
                y3[i] = Convert.ToInt32(dt3.Rows[i][1]);
            }


            Chart3.Series[0].Points.DataBindXY(x3, y3);

            Chart3.Series[0].ChartType = System.Web.UI.DataVisualization.Charting.SeriesChartType.Column;

            string[] x4 = new string[dt4.Rows.Count];
            int[] y4 = new int[dt4.Rows.Count];
            for (int i = 0; i < dt4.Rows.Count; i++)
            {
                x4[i] = dt4.Rows[i][0].ToString();
                y4[i] = Convert.ToInt32(dt4.Rows[i][1]);
            }


            Chart4.Series[0].Points.DataBindXY(x4, y4);

            Chart4.Series[0].ChartType = System.Web.UI.DataVisualization.Charting.SeriesChartType.Doughnut;


        }

        protected void Chart1_Load(object sender, EventArgs e)
        {

        }

        protected void Chart2_Load(object sender, EventArgs e)
        {

        }
    }
}
